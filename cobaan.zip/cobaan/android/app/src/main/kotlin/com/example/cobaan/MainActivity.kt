package com.example.cobaan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
