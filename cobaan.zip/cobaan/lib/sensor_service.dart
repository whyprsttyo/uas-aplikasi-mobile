import 'package:sensors/sensors.dart';
import 'dart:async';

class SensorService {
  final StreamController<AccelerometerEvent> _controller = StreamController<AccelerometerEvent>();

  SensorService() {
    accelerometerEvents.listen((event) {
      _controller.add(event);
    });
  }

  Stream<AccelerometerEvent> get accelerometerStream => _controller.stream;

  void dispose() {
    _controller.close();
  }
}
