package com.example.motionsensorapp;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.lifecycleScope;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private AppDatabase db;
    private TextView sensorDataView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        sensorDataView = findViewById(R.id.sensor_data);
        db = AppDatabase.getInstance(this);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            long timestamp = System.currentTimeMillis();

            SensorData sensorData = new SensorData(x, y, z, timestamp);

            lifecycleScope.launch {
                db.sensorDataDao().insert(sensorData);
                updateUI();
            }
        }
    }

    private void updateUI() {
        lifecycleScope.launch {
            List<SensorData> allData = db.sensorDataDao().getAllData();
            StringBuilder dataString = new StringBuilder();
            for (SensorData data : allData) {
                dataString.append("X: ").append(data.x)
                        .append(", Y: ").append(data.y)
                        .append(", Z: ").append(data.z)
                        .append("\n");
            }
            sensorDataView.setText(dataString.toString());
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not implemented
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
}
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    tools:context=".MainActivity">

    <TextView
        android:id="@+id/sensor_data"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:text="Sensor data will appear here"
        android:textSize="18sp"/>
</LinearLayout>
